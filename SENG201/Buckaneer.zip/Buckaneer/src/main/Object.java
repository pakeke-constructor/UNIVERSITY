package main;

import java.awt.Graphics;
import java.awt.Image;

public class Object extends GameLogic{
	private Image sprite;
	private int x;
	private int y;

	
	public Object(Image imgSprite, int posX, int posY) {
		/*
		@param imgSprite the image the object takes
		@param posX x position
		@param posY y position
		*/
		sprite = imgSprite;
		x = posX;
		y = posY;
	}
	
	public int getX() {
		// @return X position
		return x;
	}
	
	public int getY() {
		// @return Y position
		return y;
	}
	
	public void setX(int newX) {
		// @param newX sets x position to this
		x = newX;
	}
	
	public void setY(int newY) {
		// @param newY sets y position to this
		y = newY;
	}
}
