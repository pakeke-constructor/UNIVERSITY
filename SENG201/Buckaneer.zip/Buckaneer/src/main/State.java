package main;

public enum State {
	MAP,
	MENU,
	SHOP,
	GAMEOVER,
	INVENTORY,
	PRICEINFO
}
