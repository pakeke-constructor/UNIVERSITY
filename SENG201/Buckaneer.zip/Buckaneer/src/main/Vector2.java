package main;

public class Vector2 {
	public int x;
	public int y;
	
	public Vector2() {
		x = 0;
		y = 0;
	}
	
	public Vector2(int posX, int posY) {
		x = posX;
		y = posY;
	}
	
	
}
