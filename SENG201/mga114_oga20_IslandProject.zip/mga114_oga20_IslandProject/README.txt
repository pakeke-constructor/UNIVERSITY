______________________________________________________________________________
Running .jar in linux:
==============================================================================
	navigate to the directory buckaneer.jar is located (This is important)
	java -jar ./buckaneer.jar
==============================================================================



______________________________________________________________________________
BUILDING PROJECT FROM ECLIPSE:
==============================================================================
Open the project in Eclipse
Click file, export, and choose Java -> JAR File
Click "Next"
On the resources to export, select all, then remove these files:
  - Diagram.ucls
  - buckaneer.jar
  - .classpath
Click next twice
Select the application entry point as Main
Click finish
Ensure to always run the Jar file in a directory that
	has the /images folder, else it will not function.
==============================================================================
